import random
import time

def intro():
    """Display game introduction."""
    print('\nWelcome to the Pentelay Game!')
    time.sleep(1)
    print('You have 5 shots to hit the target.')
    print('Good luck!')
    print('-' * 40)
    time.sleep(1)

def get_player_direction():
    """Prompt user for shot direction with input validation."""
    while True:
        print('\nChoose your direction:')
        print('1. Far left')
        print('2. Left')
        print('3. Center')
        print('4. Right')
        print('5. Far right')
        choice = input('Enter your choice (1-5): ')
        if choice in ['1', '2', '3', '4', '5']:
            return choice
        else:
            print('Invalid choice, try again.')

def get_player_power():
    """Prompt user for shot power with input validation."""
    while True:
        print('\nChoose your shot power:')
        print('1. Low')
        print('2. Medium')
        print('3. High')
        power = input('Enter your choice (1-3): ')
        if power in ['1', '2', '3']:
            return power
        else:
            print('Invalid choice, try again.')

def shoot(number):
    """Handle one shot attempt, return 1 if goal scored, 0 otherwise."""
    print(f'\nShot number {number}...')
    time.sleep(1)

    player_direction = get_player_direction()
    player_power = get_player_power()

    # Random keeper direction with weight (more likely to go center)
    keeper_weights = [1, 2, 3, 2, 1]
    keeper_direction = str(random.choices(['1', '2', '3', '4', '5'], weights=keeper_weights)[0])
    keeper_skill = random.randint(1, 3)

    print(f'\nYou shoot toward direction {player_direction} with power {player_power}.')
    time.sleep(1)
    print(f'The keeper dives to direction {keeper_direction} with skill {keeper_skill}.')
    time.sleep(1)

    if player_direction == keeper_direction:
        if int(player_power) > keeper_skill:
            print('Goal! You beat the keeper.')
            return 1
        else:
            print('Missed! The keeper saved your shot.')
            return 0
    else:
        print('Goal! You scored.')
        return 1

def play_game():
    """Run the full game loop."""
    intro()
    score = 0
    for i in range(1, 6):
        score += shoot(i)
        print(f'Current score: {score}\n')
        time.sleep(1)

    print(f'\nGame over! You scored {score} goal(s).')
    if score >= 3:
        print('🎉 Congratulations! You won the game!')
    else:
        print('😢 Sorry, you lost the game.')

    play_again()

def play_again():
    """Ask the player if they want to play again."""
    while True:
        choice = input('\nDo you want to play again? (y/n): ').lower()
        if choice == 'y':
            play_game()
            break
        elif choice == 'n':
            print('Thanks for playing Pentelay Game!')
            break
        else:
            print('Invalid input. Please enter "y" or "n".')

# Start the game
play_game()